import 'package:flutter/material.dart';
import 'package:hotel/pages/color_page.dart';
import 'package:hotel/pages/home_page.dart';
import 'package:hotel/pages/welcome_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: kPrimaryColor,
        scaffoldBackgroundColor: kBacgroundColor,
        textTheme: TextTheme(
          headlineSmall: const TextStyle(
            backgroundColor: kBacgroundColor,
            color: kPrimaryColor,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
          titleSmall: TextStyle(
            color: Colors.white.withOpacity(.7),
            fontWeight: FontWeight.normal,
          ),
          labelLarge: const TextStyle(
            color: kBacgroundColor,
          ),
          labelMedium: const TextStyle(
            color: kBacgroundColor,
            fontSize: 25,
            fontWeight: FontWeight.bold,
          )
        ),
        inputDecorationTheme: InputDecorationTheme(
          hintStyle: TextStyle(
              color: kBacgroundColor.withOpacity(.7),
              fontWeight: FontWeight.w400
          ),
          fillColor: kPrimaryColor.withOpacity(.8),
          filled: true,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(25),
              borderSide: const BorderSide(
                width: 0,
                style: BorderStyle.none,
              ),
          ),
        ),
      ),
      home: const WelcomePage(),
    );
  }
}
