import 'package:date_field/date_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hotel/pages/color_page.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AddReservationPage extends StatefulWidget {
  const AddReservationPage({Key? key}) : super(key: key);

  @override
  State<AddReservationPage> createState() => _AddReservationPageState();
}

class _AddReservationPageState extends State<AddReservationPage> {
  final _formKey = GlobalKey<FormState>();
  // Pour controler les champs de text
  final lastNameController = TextEditingController();
  final firstNameController = TextEditingController();
  final phoneNumberController = TextEditingController();
  final addressController = TextEditingController();
  final mailController = TextEditingController();
  //Pour récupérer le type de catégorie de réservation
  String selectedCategoryType = 'economique';
  DateTime selectedDate = DateTime.now();

  @override
  void dispose() {
    //Pour libérer de la mémoire
    super.dispose();

    lastNameController.dispose();
    firstNameController.dispose();
    phoneNumberController.dispose();
    addressController.dispose();
    mailController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double height = MediaQuery.of(context).size.height;
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
    return Container(
      margin: const EdgeInsets.all(20),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // SizedBox(
            //   height: height * 0.04,
            // ),
            Container(
              margin: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Faire une',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      Text(
                        'Réservation',
                        style: TextStyle(
                          fontSize: 22,
                          color: kPrimaryColor.withOpacity(.5),
                        ),
                      ),
                    ],
                  ),
                  const CircleAvatar(),
                ],
              ),
            ),
            SizedBox(
              height: height * 0.05,
            ),
            Container(
              margin: const EdgeInsets.only(
                bottom: 10,
              ),
              child: TextFormField(
                controller: lastNameController,
                decoration: InputDecoration(
                  labelText: 'Prenom',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                    ),
                  ),
                  fillColor: kPrimaryColor,
                  filled: true,
                  labelStyle: const TextStyle(
                    color: kBacgroundColor,
                  ),
                  isCollapsed: false,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Ce champs ne doit pas être vide !";
                  }
                  return null;
                },
              ),
            ),
            Container(
              // color: kPrimaryColor,
              margin: const EdgeInsets.only(bottom: 10),
              child: TextFormField(
                controller: firstNameController,
                decoration: InputDecoration(
                  labelText: 'Nom',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                    ),
                  ),
                  fillColor: kPrimaryColor,
                  filled: true,
                  labelStyle: const TextStyle(
                    color: kBacgroundColor,
                  ),
                  isCollapsed: false,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Ce champs ne doit pas être vide !";
                  }
                  return null;
                },
              ),
            ),
            Container(
              // color: kPrimaryColor,
              margin: const EdgeInsets.only(bottom: 10),
              child: TextFormField(
                controller: phoneNumberController,
                decoration: InputDecoration(
                  labelText: 'Téléphone',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                    ),
                  ),
                  fillColor: kPrimaryColor,
                  filled: true,
                  // ignore: prefer_const_constructors
                  labelStyle: TextStyle(
                    color: kBacgroundColor,
                  ),
                  isCollapsed: false,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Ce champs ne doit pas être vide !";
                  }
                  return null;
                },
              ),
            ),
            Container(
              // color: kPrimaryColor,
              margin: const EdgeInsets.only(bottom: 10),
              child: TextFormField(
                controller: addressController,
                decoration: InputDecoration(
                  labelText: 'Adresse',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                    ),
                  ),
                  fillColor: kPrimaryColor,
                  filled: true,
                  // ignore: prefer_const_constructors
                  labelStyle: TextStyle(
                    color: kBacgroundColor,
                  ),
                  isCollapsed: false,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Ce champs ne doit pas être vide !";
                  }
                  return null;
                },
              ),
            ),
            Container(
              // color: kPrimaryColor,
              margin: const EdgeInsets.only(bottom: 10),
              child: TextFormField(
                controller: mailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                    ),
                  ),
                  fillColor: kPrimaryColor,
                  filled: true,
                  labelStyle: const TextStyle(
                    color: kBacgroundColor,
                  ),
                  isCollapsed: false,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Ce champs ne doit pas être vide !";
                  }
                  return null;
                },
              ),
            ),
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              child: DateTimeFormField(
                decoration: InputDecoration(
                  labelText: 'Date de réservation',
                  border: OutlineInputBorder(
                    borderSide: const BorderSide(
                      width: 0,
                      color: kPrimaryColor,
                      style: BorderStyle.none,
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  fillColor: kPrimaryColor,
                  filled: true,
                  labelStyle: const TextStyle(
                    color: kBacgroundColor,
                  ),
                  isCollapsed: false,
                  errorStyle: const TextStyle(color: Colors.redAccent),
                  suffixIcon: const Icon(
                    Icons.event_note,
                    color: kBacgroundColor,
                  ),
                ),
                mode: DateTimeFieldPickerMode.dateAndTime,
                autovalidateMode: AutovalidateMode.always,
                // validator: (e) => (e?.day ?? 0) == 1 ? 'Please not the first day' : null,
                onDateSelected: (DateTime value) {
                  setState(() {
                    selectedDate = value;
                  });
                },
              ),
            ),
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              child: DropdownButtonFormField(
                elevation: 4,
                dropdownColor: kPrimaryColor,
                iconEnabledColor: kBacgroundColor,
                style: GoogleFonts.poppins(
                  color: kBacgroundColor,
                  letterSpacing: 0.5,
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'economique',
                    child: Text('Economique'),
                  ),
                  DropdownMenuItem(
                    value: 'standing',
                    child: Text('Standing'),
                  ),
                  DropdownMenuItem(
                    value: 'affaire',
                    child: Text('Affaire'),
                  ),
                ],
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                    ),
                  ),
                  fillColor: kPrimaryColor,
                  filled: true,
                  isCollapsed: false,
                ),
                value: selectedCategoryType,
                onChanged: (value) {
                  setState(() {
                    selectedCategoryType = value!;
                  });
                },
              ),
            ),
            SizedBox(
              height: height * 0.04,
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: kPrimaryColor,
              ),
              child: IconButton(
                icon:  FaIcon(FontAwesomeIcons.arrowRightLong, color: kBacgroundColor.withOpacity(.7),),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    //Pour récupérer les données
                    final lastName = lastNameController.text;
                    final firstName = firstNameController.text;

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        backgroundColor: kPrimaryColor,
                        content: Text('En cours d\'envoi...'),
                      ),
                    );
                    FocusScope.of(context).requestFocus(
                      FocusNode(),
                    );

                    /* print("Le nom du client est $lastName et son prénom est $firstName");
                  print('Type de categorie $selectedCategoryType');
                  print('La date de rèservation est $selectedDate'); */
                  }
                },
                // child: const Text('Envoyer'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
