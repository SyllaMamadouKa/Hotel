import 'package:flutter/material.dart';
import 'package:hotel/pages/add_reservation_page.dart';
import 'package:hotel/pages/color_page.dart';
import 'package:hotel/pages/customer_page.dart';
import 'package:hotel/pages/home_page.dart';
import 'package:hotel/pages/facture_page.dart';
import 'package:hotel/pages/room_page.dart';
import 'package:hotel/pages/statistique_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _currentIndex = 0;

  setCurrentIndex(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  List pages = [
    const HomePage(),
    const RoomPage(),
    const AddReservationPage(),
    const FacturePage(),
    const CustomerPage(),
    const StatistiquePage()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      /*  */
      body: SingleChildScrollView(
        child: pages[_currentIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: kPrimaryColor,
        //Fixer les éléments de la BottomNavigationBar quand ils sont trop nombreux
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        onTap: (index) => setCurrentIndex(index),
        selectedItemColor: kBacgroundColor,
        unselectedItemColor: Colors.grey.withOpacity(.5),
        showUnselectedLabels: false,
        showSelectedLabels: false,
        elevation: 0,
        iconSize: 30,

        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.apps),
            label: "Accueil",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bed),
            label: "Chambres",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_add_alt_1),
            label: "Ajout",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.inventory_rounded),
            label: "Factures",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.group_rounded),
            label: "Client",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart_sharp),
            label: "Statistiques",
          ),
        ],
      ),
    );
  }
}
