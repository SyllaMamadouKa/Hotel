import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hotel/pages/color_page.dart';
import 'package:hotel/pages/home_page.dart';
import 'package:hotel/pages/main_page.dart';

class SignInPage extends StatelessWidget {
  const SignInPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top,
            ),
          ),
          Expanded(
            flex: 2,
            child: SvgPicture.asset(
              'images/si.svg',
            ),
          ),
          const SizedBox(height: 30),
          Expanded(
            flex: 3,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
              ),
              child: Column(
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(

                          color: kPrimaryColor.withOpacity(.8),
                          borderRadius: BorderRadius.circular(12),
                          shape: BoxShape.rectangle,
                          border: Border.all(
                            color: kBacgroundColor,
                          ),
                        ),
                        child: Text(
                          "SIGN IN",
                          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 22, color: kBacgroundColor,),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: kPrimaryColor.withOpacity(.8),
                          borderRadius: BorderRadius.circular(12),
                          shape: BoxShape.rectangle,
                          border: Border.all(
                            color: kPrimaryColor,
                          ),
                        ),
                        child: Text(
                          'SIGN UP',
                          style: GoogleFonts.poppins(color: kBacgroundColor, fontWeight: FontWeight.bold, ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                      Expanded(
                        flex: 2,
                        child: TextField(
                          decoration: InputDecoration(
                            prefixIcon: Icon(Icons.alternate_email, color: kBacgroundColor.withOpacity(.7),),
                            hintText: 'Email Address',
                          ),
                        ),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                      Expanded(
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: 'Password',
                            prefixIcon:  Icon(Icons.lock, color: kBacgroundColor.withOpacity(.7),),
                          ),
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) {
                            return const MainPage();
                          },
                        ),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 26,
                        vertical: 16,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        color: kPrimaryColor.withOpacity(.8),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'Valider',
                            style: GoogleFonts.poppins(color: kBacgroundColor,
                              fontSize: 20),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
