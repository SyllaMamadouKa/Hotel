import 'package:flutter/material.dart';

class FacturePage extends StatelessWidget {
  const FacturePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      child: const Text('Pas encore disponible'),
    );
  }
}
