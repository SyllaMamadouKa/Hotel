import 'package:flutter/material.dart';
import 'package:hotel/pages/color_page.dart';
import 'package:hotel/pages/models/luxury_room.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final categories = [
    {
      'icon': Icons.bedroom_parent,
      'color': const Color.fromARGB(255, 48, 246, 177),
      'title': 'Classe',
    },
    {
      'icon': Icons.bedroom_child_sharp,
      'color': const Color.fromARGB(255, 81, 108, 246),
      'title': 'Médium',
    },
    {
      'icon': Icons.bed_sharp,
      'color': const Color(0xFF621cf4),
      'title': 'Soft',
    },
    {
      'icon': Icons.bedroom_parent_rounded,
      'color': const Color(0xFF603d9f4),
      'title': 'High',
    },
    {
      'icon': Icons.bedroom_baby,
      'color': const Color.fromARGB(246, 244, 3, 59),
      'title': 'Classique',
    },
  ];

  final List<Luxury> luxuries = Luxury.luxuries();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top,
          // left: 10,
          // right: 10,
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Le Havre,',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      const Text(
                        'Échappez-vous vers un monde de confort et de luxe',
                        style: TextStyle(
                          fontSize: 12,
                          color: kPrimaryColor,
                        ),
                      ),
                    ],
                  ),
                  CircleAvatar(
                    child: Image.asset('images/h1.png'),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(25),
              child: Stack(
                children: [
                  TextField(
                    decoration: InputDecoration(
                      suffixIcon: const Icon(
                        Icons.mic_outlined,
                        color: kBacgroundColor,
                        size: 35,
                      ),
                      fillColor: kPrimaryColor,
                      filled: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: const BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                        ),
                      ),
                      prefixIcon: const Icon(
                        Icons.search_outlined,
                        size: 30,
                        color: kBacgroundColor,
                      ),
                      hintText: 'Rechercher',
                      hintStyle: TextStyle(
                        color: kBacgroundColor.withOpacity(.5),
                        fontSize: 20,
                      ),
                    ),
                  ),
                  // Positioned(
                  //   top: 5,
                  //   right: 10,
                  //   bottom: 5,
                  //   child: Container(
                  //     // width: 50,
                  //     // height: 50,
                  //     // color: Colors.red,
                  //     // padding: EdgeInsets.all(3),
                  //     margin: const EdgeInsets.symmetric(vertical: 3),
                  //     decoration: BoxDecoration(
                  //       color: const Color(0xFF5f67ea),
                  //       borderRadius: BorderRadius.circular(10),
                  //     ),
                  //     child: const Icon(
                  //       Icons.mic_outlined,
                  //       color: kPrimaryColor,
                  //       size: 35,
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),
            Container(
              height: 500,
              decoration: const BoxDecoration(
                color: kPrimaryColor,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 140,
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 25),
                      scrollDirection: Axis.horizontal,
                      itemBuilder: ((context, index) => Column(
                            children: [
                              const SizedBox(height: 25),
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: categories[index]['color'] as Color,
                                ),
                                child: Icon(
                                  categories[index]['icon'] as IconData,
                                  color: kPrimaryColor,
                                  size: 40,
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                categories[index]['title'] as String,
                                style: TextStyle(
                                  color: Colors.black.withOpacity(.7),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          )),
                      separatorBuilder: ((context, index) => const SizedBox(
                            width: 33,
                          )),
                      itemCount: categories.length,
                    ),
                  ),
                  const Text(
                    'Suites luxueuses',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 25,
                    ),
                  ),
                  Container(
                    height: 200,
                    padding: const EdgeInsets.all(10),
                    child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemBuilder: ((context, index) => GestureDetector(
                              onTap: () => print('On tap'),
                              child: Card(
                                elevation: 5,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Container(
                                  padding: const EdgeInsets.all(5),
                                  child: ClipPath(
                                    child: Image.asset(luxuries[index].bgImage),
                                  ),
                                ),
                              ),
                            )),
                        separatorBuilder: ((context, index) => const SizedBox(
                              width: 10,
                            )),
                        itemCount: luxuries.length),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
