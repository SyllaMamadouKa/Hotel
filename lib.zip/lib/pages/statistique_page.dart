import 'package:flutter/material.dart';

class StatistiquePage extends StatelessWidget {
  const StatistiquePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      child: Text('Pas encore disponible'),
    );
  }
}
