import 'package:flutter/material.dart';

// const kBacgroundColor = Color(0xFF363f93);
const kBacgroundColor = Color(0xFF5f67ea);
const kPrimaryColor = Colors.white;
