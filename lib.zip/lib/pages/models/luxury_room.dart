import 'dart:core';

class Luxury {
  String bgImage;
  String icon;
  String name;
  String categorie;
  num etage;
  String description;
  num note;
  List<String> images;

  Luxury(
    this.bgImage,
    this.icon,
    this.name,
    this.categorie,
    this.etage,
    this.description,
    this.note,
    this.images,
  );

  static List<Luxury> luxuries() {
    return [
      Luxury(
        'images/ch10.jpg',
        'images/h1.png',
        'Chambre pour deux',
        'Familiale',
        2,
        'Les chambres de l\'Hôtel Le Havre sont conçues pour offrir le plus grand confort à nos clients',
        172,
        [
          'images/ch1.jpg',
          'images/ch2.jpg',
          'images/ch3.jpg',
          'images/ch4.jpg',
        ],
      ),
      Luxury(
        'images/ch9.jpg',
        'images/h2.png',
        'Chambre pour deux',
        'Royale',
        3,
        'Chacune de nos chambres est équipée d\'un lit confortable avec des draps doux et des oreillers moelleux pour vous assurer une bonne nuit de sommeil',
        172,
        [
          'images/ch5.jpg',
          'images/ch6.jpg',
          'images/ch7.jpg',
          'images/ch8.jpg',
        ],
      ),
      Luxury(
        'images/ch1.jpg',
        'images/h2.png',
        'Chambre pour deux',
        'Royale',
        3,
        'Chacune de nos chambres est équipée d\'un lit confortable avec des draps doux et des oreillers moelleux pour vous assurer une bonne nuit de sommeil',
        172,
        [
          'images/ch2.jpg',
          'images/ch3.jpg',
          'images/ch4.jpg',
          'images/ch10.jpg',
        ],
      ),
    ];
  }
}
